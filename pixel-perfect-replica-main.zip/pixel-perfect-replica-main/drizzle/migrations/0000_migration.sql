
create type public.app_role as enum ('admin','moderator','user');
create type public.wish_status as enum ('draft','published','in_progress','confirmed','completed','cancelled');
create type public.fulfillment_status as enum ('pending','confirmed','completed','cancelled');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "own roles readable" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  avatar_url text,
  bio text,
  show_likes boolean not null default false,
  language text not null default 'pt',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.profiles to anon, authenticated;
grant update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "profiles public read" on public.profiles for select using (true);
create policy "profiles own update" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name, avatar_url)
  values (new.id,
    left(coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email,'@',1), 'Utilizador'), 60),
    new.raw_user_meta_data->>'avatar_url');
  insert into public.user_roles (user_id, role) values (new.id, 'user');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create table public.wishes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 3 and 120),
  description text not null check (char_length(description) between 10 and 3000),
  category text not null,
  image_url text,
  link_url text,
  reference_price numeric(12,2) check (reference_price is null or reference_price >= 0),
  currency text not null default 'EUR',
  store text,
  country text not null,
  status public.wish_status not null default 'published',
  hidden boolean not null default false,
  likes_count integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index wishes_status_created on public.wishes(status, created_at desc);
grant select on public.wishes to anon, authenticated;
grant insert, update, delete on public.wishes to authenticated;
grant all on public.wishes to service_role;
alter table public.wishes enable row level security;
create policy "wishes public read" on public.wishes for select using ((status <> 'draft' and hidden = false) or auth.uid() = user_id or public.has_role(auth.uid(),'admin') or public.has_role(auth.uid(),'moderator'));
create policy "wishes own insert" on public.wishes for insert to authenticated with check (auth.uid() = user_id and status in ('draft','published') and hidden = false and likes_count = 0);
create policy "wishes own update" on public.wishes for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "wishes mod update" on public.wishes for update to authenticated using (public.has_role(auth.uid(),'admin') or public.has_role(auth.uid(),'moderator'));
create policy "wishes own delete" on public.wishes for delete to authenticated using (auth.uid() = user_id and status in ('draft','published','cancelled'));

create or replace function public.wishes_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.updated_at := now();
  if current_setting('wishmade.system', true) = 'on' then return new; end if;
  new.likes_count := old.likes_count;
  new.user_id := old.user_id;
  if not (public.has_role(auth.uid(),'admin') or public.has_role(auth.uid(),'moderator')) then
    new.hidden := old.hidden;
    if new.status <> old.status then
      if not ((old.status in ('draft','published') and new.status in ('draft','published'))
           or (old.status = 'published' and new.status = 'cancelled')
           or (old.status = 'cancelled' and new.status = 'published')) then
        raise exception 'Invalid status change';
      end if;
    end if;
    if old.status in ('in_progress','confirmed','completed') then
      if new.title <> old.title or new.reference_price is distinct from old.reference_price or new.link_url is distinct from old.link_url then
        raise exception 'Wish cannot be edited while being fulfilled';
      end if;
    end if;
  end if;
  return new;
end $$;
create trigger wishes_guard before update on public.wishes for each row execute function public.wishes_guard();

create table public.likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  wish_id uuid not null references public.wishes(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, wish_id)
);
grant select on public.likes to anon, authenticated;
grant insert, delete on public.likes to authenticated;
grant all on public.likes to service_role;
alter table public.likes enable row level security;
create policy "likes read" on public.likes for select using (auth.uid() = user_id or exists (select 1 from public.profiles p where p.id = user_id and p.show_likes));
create policy "likes own insert" on public.likes for insert to authenticated with check (auth.uid() = user_id);
create policy "likes own delete" on public.likes for delete to authenticated using (auth.uid() = user_id);

create table public.fulfillments (
  id uuid primary key default gen_random_uuid(),
  wish_id uuid not null references public.wishes(id) on delete cascade,
  giver_id uuid not null references public.profiles(id) on delete cascade,
  status public.fulfillment_status not null default 'pending',
  message text check (message is null or char_length(message) <= 1000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index fulfillments_one_active on public.fulfillments(wish_id) where status in ('pending','confirmed','completed');
create unique index fulfillments_once_per_giver on public.fulfillments(wish_id, giver_id) where status <> 'cancelled';
grant select on public.fulfillments to authenticated;
grant all on public.fulfillments to service_role;
alter table public.fulfillments enable row level security;
create policy "fulfillments parties read" on public.fulfillments for select to authenticated using (auth.uid() = giver_id or exists (select 1 from public.wishes w where w.id = wish_id and w.user_id = auth.uid()));

create table public.fulfillment_events (
  id uuid primary key default gen_random_uuid(),
  fulfillment_id uuid not null references public.fulfillments(id) on delete cascade,
  actor_id uuid not null,
  from_status public.fulfillment_status,
  to_status public.fulfillment_status not null,
  created_at timestamptz not null default now()
);
grant select on public.fulfillment_events to authenticated;
grant all on public.fulfillment_events to service_role;
alter table public.fulfillment_events enable row level security;
create policy "events parties read" on public.fulfillment_events for select to authenticated using (exists (select 1 from public.fulfillments f join public.wishes w on w.id = f.wish_id where f.id = fulfillment_id and (f.giver_id = auth.uid() or w.user_id = auth.uid())));

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  type text not null,
  wish_id uuid references public.wishes(id) on delete cascade,
  fulfillment_id uuid references public.fulfillments(id) on delete cascade,
  actor_id uuid,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index notifications_user on public.notifications(user_id, created_at desc);
grant select, update, delete on public.notifications to authenticated;
grant all on public.notifications to service_role;
alter table public.notifications enable row level security;
create policy "notif own read" on public.notifications for select to authenticated using (auth.uid() = user_id);
create policy "notif own update" on public.notifications for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "notif own delete" on public.notifications for delete to authenticated using (auth.uid() = user_id);

create or replace function public.likes_count_sync() returns trigger
language plpgsql security definer set search_path = public as $$
declare w record;
begin
  perform set_config('wishmade.system','on',true);
  if tg_op = 'INSERT' then
    update public.wishes set likes_count = likes_count + 1 where id = new.wish_id returning user_id into w;
    if w.user_id <> new.user_id then
      insert into public.notifications(user_id, type, wish_id, actor_id) values (w.user_id, 'like', new.wish_id, new.user_id);
    end if;
  else
    update public.wishes set likes_count = greatest(likes_count - 1, 0) where id = old.wish_id;
  end if;
  perform set_config('wishmade.system','off',true);
  return null;
end $$;
create trigger likes_count_sync after insert or delete on public.likes for each row execute function public.likes_count_sync();

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null,
  wish_id uuid references public.wishes(id) on delete cascade,
  reported_user_id uuid references public.profiles(id) on delete cascade,
  reason text not null,
  details text check (details is null or char_length(details) <= 1000),
  status text not null default 'open',
  created_at timestamptz not null default now(),
  check (wish_id is not null or reported_user_id is not null)
);
grant select, insert, update on public.reports to authenticated;
grant all on public.reports to service_role;
alter table public.reports enable row level security;
create policy "reports insert own" on public.reports for insert to authenticated with check (auth.uid() = reporter_id and status = 'open');
create policy "reports read own or mod" on public.reports for select to authenticated using (auth.uid() = reporter_id or public.has_role(auth.uid(),'admin') or public.has_role(auth.uid(),'moderator'));
create policy "reports mod update" on public.reports for update to authenticated using (public.has_role(auth.uid(),'admin') or public.has_role(auth.uid(),'moderator'));

create or replace function public.start_fulfillment(_wish_id uuid, _message text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare w record; fid uuid; recent int;
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  select * into w from public.wishes where id = _wish_id for update;
  if not found or w.hidden then raise exception 'Wish not found'; end if;
  if w.user_id = auth.uid() then raise exception 'You cannot fulfill your own wish'; end if;
  if w.status <> 'published' then raise exception 'This wish is not accepting fulfillments'; end if;
  if exists (select 1 from public.fulfillments where wish_id = _wish_id and giver_id = auth.uid()) then raise exception 'You already tried to fulfill this wish'; end if;
  select count(*) into recent from public.fulfillments where giver_id = auth.uid() and created_at > now() - interval '1 hour';
  if recent >= 5 then raise exception 'Too many requests, try later'; end if;
  insert into public.fulfillments(wish_id, giver_id, message) values (_wish_id, auth.uid(), nullif(left(_message,1000),'')) returning id into fid;
  insert into public.fulfillment_events(fulfillment_id, actor_id, from_status, to_status) values (fid, auth.uid(), null, 'pending');
  perform set_config('wishmade.system','on',true);
  update public.wishes set status = 'in_progress' where id = _wish_id;
  perform set_config('wishmade.system','off',true);
  insert into public.notifications(user_id, type, wish_id, fulfillment_id, actor_id) values (w.user_id, 'fulfillment_started', _wish_id, fid, auth.uid());
  return fid;
end $$;

create or replace function public.transition_fulfillment(_id uuid, _to public.fulfillment_status)
returns void language plpgsql security definer set search_path = public as $$
declare f record; w record; me uuid := auth.uid(); other uuid; new_wish public.wish_status;
begin
  if me is null then raise exception 'Not authenticated'; end if;
  select * into f from public.fulfillments where id = _id for update;
  if not found then raise exception 'Not found'; end if;
  select * into w from public.wishes where id = f.wish_id for update;
  if me <> f.giver_id and me <> w.user_id then raise exception 'Not allowed'; end if;
  if _to = 'confirmed' and f.status = 'pending' and me = w.user_id then new_wish := 'confirmed';
  elsif _to = 'completed' and f.status = 'confirmed' and me = w.user_id then new_wish := 'completed';
  elsif _to = 'cancelled' and f.status in ('pending','confirmed') then new_wish := 'published';
  else raise exception 'Invalid transition';
  end if;
  update public.fulfillments set status = _to, updated_at = now() where id = _id;
  insert into public.fulfillment_events(fulfillment_id, actor_id, from_status, to_status) values (_id, me, f.status, _to);
  perform set_config('wishmade.system','on',true);
  update public.wishes set status = new_wish where id = w.id;
  perform set_config('wishmade.system','off',true);
  other := case when me = f.giver_id then w.user_id else f.giver_id end;
  insert into public.notifications(user_id, type, wish_id, fulfillment_id, actor_id) values (other, 'fulfillment_' || _to::text, w.id, _id, me);
end $$;

revoke execute on function public.start_fulfillment(uuid, text) from anon, public;
revoke execute on function public.transition_fulfillment(uuid, public.fulfillment_status) from anon, public;
grant execute on function public.start_fulfillment(uuid, text) to authenticated;
grant execute on function public.transition_fulfillment(uuid, public.fulfillment_status) to authenticated;

create policy "wish images public read" on storage.objects for select using (bucket_id = 'wish-images');
create policy "wish images own upload" on storage.objects for insert to authenticated with check (bucket_id = 'wish-images' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "wish images own delete" on storage.objects for delete to authenticated using (bucket_id = 'wish-images' and (storage.foldername(name))[1] = auth.uid()::text);
