import type { Lang } from "./i18n";

type QA = { q: string; a: string };

export const FAQ: Record<Lang, QA[]> = {
  pt: [
    { q: "Preciso de conta para ver desejos?", a: "Não. Qualquer pessoa pode explorar e pesquisar desejos. Para publicar, gostar ou realizar um desejo é preciso iniciar sessão." },
    { q: "O que acontece quando clico em “Realizar desejo”?", a: "Inicias um processo. O autor é notificado e tem de confirmar. O desejo só fica concluído quando o autor o marcar como recebido." },
    { q: "Posso pagar diretamente na Wishmade?", a: "Ainda não. Os pagamentos integrados estão em preparação e só serão ativados quando todo o processo (pagamento, reembolsos, apoio) estiver validado. Por agora, a compra ou reserva é feita na loja ou plataforma de origem." },
    { q: "A minha morada fica visível?", a: "Não. A Wishmade não pede nem mostra moradas em perfis ou desejos. Nunca publiques dados privados na descrição." },
    { q: "Os preços são reais?", a: "O preço indicado é de referência, introduzido pelo autor ou lido da página da loja. Não é verificado e pode mudar." },
    { q: "Mais do que uma pessoa pode realizar o mesmo desejo?", a: "Na primeira versão, cada desejo é realizado por uma única pessoa. Se o processo for cancelado, o desejo volta a estar disponível." },
  ],
  en: [
    { q: "Do I need an account to see wishes?", a: "No. Anyone can explore and search wishes. To post, like or fulfil a wish you need to sign in." },
    { q: "What happens when I click “Fulfil wish”?", a: "You start a process. The author is notified and must confirm. The wish is only completed when the author marks it as received." },
    { q: "Can I pay directly on Wishmade?", a: "Not yet. Integrated payments are being prepared and will only be enabled once the full process (payment, refunds, support) is validated. For now, purchase or booking happens on the original store or platform." },
    { q: "Is my address visible?", a: "No. Wishmade doesn't ask for or show addresses on profiles or wishes. Never post private data in descriptions." },
    { q: "Are prices real?", a: "The price shown is a reference, entered by the author or read from the store page. It isn't verified and may change." },
    { q: "Can more than one person fulfil the same wish?", a: "In the first version each wish is fulfilled by a single person. If the process is cancelled, the wish becomes available again." },
  ],
  es: [
    { q: "¿Necesito cuenta para ver deseos?", a: "No. Cualquiera puede explorar y buscar deseos. Para publicar, dar me gusta o cumplir un deseo hay que iniciar sesión." },
    { q: "¿Qué pasa al pulsar “Cumplir deseo”?", a: "Inicias un proceso. El autor recibe un aviso y debe confirmar. El deseo solo se completa cuando el autor lo marca como recibido." },
    { q: "¿Puedo pagar directamente en Wishmade?", a: "Todavía no. Los pagos integrados están en preparación y solo se activarán cuando todo el proceso (pago, reembolsos, soporte) esté validado. Por ahora, la compra o reserva se hace en la tienda o plataforma de origen." },
    { q: "¿Mi dirección es visible?", a: "No. Wishmade no pide ni muestra direcciones en perfiles o deseos. Nunca publiques datos privados en la descripción." },
    { q: "¿Los precios son reales?", a: "El precio mostrado es de referencia, introducido por el autor o leído de la página de la tienda. No está verificado y puede cambiar." },
    { q: "¿Puede más de una persona cumplir el mismo deseo?", a: "En la primera versión, cada deseo lo cumple una sola persona. Si se cancela el proceso, el deseo vuelve a estar disponible." },
  ],
};

type Section = { h: string; p: string };
export type LegalKey = "terms" | "privacy" | "cookies" | "rules" | "help";

export const LEGAL: Record<LegalKey, Record<Lang, Section[]>> = {
  terms: {
    pt: [
      { h: "1. Objeto", p: "A Wishmade é uma plataforma que permite partilhar desejos e propor a sua realização por outras pessoas. A Wishmade não vende diretamente os produtos ou serviços indicados nos desejos." },
      { h: "2. Conta", p: "Para publicar, gostar ou realizar desejos é necessária uma conta. És responsável pela veracidade da informação e pela segurança das tuas credenciais. A plataforma destina-se a maiores de 18 anos." },
      { h: "3. Conteúdo", p: "Só podes publicar desejos verdadeiros, sem informação inventada, e imagens que tenhas direito a usar. Conteúdo proibido pode ser removido e a conta suspensa." },
      { h: "4. Realizações e pagamentos", p: "Iniciar uma realização não constitui pagamento nem obrigação de compra. Os pagamentos integrados ainda não estão disponíveis. Compras e reservas em lojas externas regem-se pelas condições dessas lojas." },
      { h: "5. Responsabilidade", p: "Preços e disponibilidade indicados são de referência e podem mudar. A Wishmade não garante a exatidão de dados introduzidos por utilizadores ou obtidos de terceiros." },
    ],
    en: [
      { h: "1. Purpose", p: "Wishmade is a platform for sharing wishes and offering to fulfil them. Wishmade does not directly sell the products or services shown in wishes." },
      { h: "2. Account", p: "An account is needed to post, like or fulfil wishes. You're responsible for accurate information and keeping your credentials secure. The platform is for people aged 18+." },
      { h: "3. Content", p: "Only post genuine wishes, without invented information, and images you have the right to use. Prohibited content may be removed and accounts suspended." },
      { h: "4. Fulfilments and payments", p: "Starting a fulfilment is not a payment nor an obligation to buy. Integrated payments are not available yet. Purchases and bookings on external stores follow those stores' terms." },
      { h: "5. Liability", p: "Prices and availability are references and may change. Wishmade doesn't guarantee the accuracy of data entered by users or obtained from third parties." },
    ],
    es: [
      { h: "1. Objeto", p: "Wishmade es una plataforma para compartir deseos y proponer cumplirlos. Wishmade no vende directamente los productos o servicios indicados en los deseos." },
      { h: "2. Cuenta", p: "Se necesita una cuenta para publicar, dar me gusta o cumplir deseos. Eres responsable de la veracidad de la información y de la seguridad de tus credenciales. La plataforma es para mayores de 18 años." },
      { h: "3. Contenido", p: "Publica solo deseos reales, sin información inventada, e imágenes que tengas derecho a usar. El contenido prohibido puede ser eliminado y la cuenta suspendida." },
      { h: "4. Propuestas y pagos", p: "Iniciar una propuesta no es un pago ni una obligación de compra. Los pagos integrados aún no están disponibles. Las compras y reservas en tiendas externas se rigen por sus condiciones." },
      { h: "5. Responsabilidad", p: "Precios y disponibilidad son de referencia y pueden cambiar. Wishmade no garantiza la exactitud de los datos introducidos por usuarios u obtenidos de terceros." },
    ],
  },
  privacy: {
    pt: [
      { h: "Dados que recolhemos", p: "Email e palavra-passe (encriptada) para a conta; nome público, fotografia e descrição opcionais; desejos, gostos, realizações e denúncias que crias." },
      { h: "O que não recolhemos", p: "Não pedimos moradas nem dados de pagamento nesta versão." },
      { h: "Finalidade", p: "Prestar o serviço, garantir a segurança, moderar conteúdo e enviar notificações relacionadas com a tua atividade." },
      { h: "Visibilidade", p: "São públicos: nome público, fotografia, descrição, desejos publicados e, se o permitires, os teus gostos. O teu email nunca é mostrado." },
      { h: "Direitos (RGPD)", p: "Podes aceder, corrigir e eliminar os teus dados e pedir a eliminação da conta através da página de Ajuda." },
    ],
    en: [
      { h: "Data we collect", p: "Email and (encrypted) password for the account; optional public name, photo and bio; wishes, likes, fulfilments and reports you create." },
      { h: "What we don't collect", p: "We don't ask for addresses or payment details in this version." },
      { h: "Purpose", p: "Provide the service, ensure security, moderate content and send notifications about your activity." },
      { h: "Visibility", p: "Public: public name, photo, bio, published wishes and, if you allow it, your likes. Your email is never shown." },
      { h: "Rights (GDPR)", p: "You can access, correct and delete your data and request account deletion via the Help page." },
    ],
    es: [
      { h: "Datos que recogemos", p: "Email y contraseña (cifrada) para la cuenta; nombre público, foto y descripción opcionales; deseos, me gusta, propuestas y denuncias que crees." },
      { h: "Lo que no recogemos", p: "No pedimos direcciones ni datos de pago en esta versión." },
      { h: "Finalidad", p: "Prestar el servicio, garantizar la seguridad, moderar contenido y enviar notificaciones sobre tu actividad." },
      { h: "Visibilidad", p: "Son públicos: nombre público, foto, descripción, deseos publicados y, si lo permites, tus me gusta. Tu email nunca se muestra." },
      { h: "Derechos (RGPD)", p: "Puedes acceder, corregir y eliminar tus datos y solicitar la eliminación de la cuenta desde la página de Ayuda." },
    ],
  },
  cookies: {
    pt: [{ h: "Cookies e armazenamento", p: "Usamos apenas armazenamento técnico essencial: a tua sessão de autenticação e a preferência de idioma. Não usamos cookies de publicidade nem de análise de terceiros." }],
    en: [{ h: "Cookies and storage", p: "We only use essential technical storage: your sign-in session and language preference. We don't use third-party advertising or analytics cookies." }],
    es: [{ h: "Cookies y almacenamiento", p: "Solo usamos almacenamiento técnico esencial: tu sesión y la preferencia de idioma. No usamos cookies publicitarias ni de análisis de terceros." }],
  },
  rules: {
    pt: [
      { h: "Permitido", p: "Desejos verdadeiros de produtos, serviços, viagens, estadias, experiências ou ajuda, descritos com honestidade." },
      { h: "Proibido", p: "Pedidos de dinheiro livre, armas, drogas, conteúdo sexual, discriminatório ou ilegal, falsificações, esquemas fraudulentos, spam, e publicação de dados pessoais (moradas, telefones, documentos)." },
      { h: "Denúncias", p: "Usa o botão “Denunciar” num desejo ou perfil. A equipa analisa cada denúncia e pode ocultar conteúdo ou suspender contas." },
    ],
    en: [
      { h: "Allowed", p: "Genuine wishes for products, services, travel, stays, experiences or help, described honestly." },
      { h: "Prohibited", p: "Requests for free cash, weapons, drugs, sexual, discriminatory or illegal content, counterfeits, scams, spam, and posting personal data (addresses, phone numbers, documents)." },
      { h: "Reports", p: "Use the “Report” button on a wish or profile. The team reviews every report and may hide content or suspend accounts." },
    ],
    es: [
      { h: "Permitido", p: "Deseos reales de productos, servicios, viajes, estancias, experiencias o ayuda, descritos con honestidad." },
      { h: "Prohibido", p: "Peticiones de dinero libre, armas, drogas, contenido sexual, discriminatorio o ilegal, falsificaciones, estafas, spam y publicación de datos personales (direcciones, teléfonos, documentos)." },
      { h: "Denuncias", p: "Usa el botón “Denunciar” en un deseo o perfil. El equipo revisa cada denuncia y puede ocultar contenido o suspender cuentas." },
    ],
  },
  help: {
    pt: [
      { h: "Precisas de ajuda?", p: "Consulta as perguntas frequentes. Para questões sobre a conta, dados pessoais ou um problema numa realização, contacta a equipa Wishmade." },
      { h: "Contacto", p: "O endereço de contacto oficial ainda não foi definido. Será publicado aqui antes do lançamento." },
      { h: "Problemas numa realização", p: "Podes cancelar uma realização em curso a partir da página de acompanhamento. Se suspeitares de fraude, usa o botão “Denunciar”." },
    ],
    en: [
      { h: "Need help?", p: "Check the FAQ. For questions about your account, personal data or an issue with a fulfilment, contact the Wishmade team." },
      { h: "Contact", p: "The official contact address hasn't been set yet. It will be published here before launch." },
      { h: "Fulfilment issues", p: "You can cancel an ongoing fulfilment from its tracking page. If you suspect fraud, use the “Report” button." },
    ],
    es: [
      { h: "¿Necesitas ayuda?", p: "Consulta las preguntas frecuentes. Para cuestiones sobre tu cuenta, datos personales o un problema en una propuesta, contacta con el equipo Wishmade." },
      { h: "Contacto", p: "La dirección de contacto oficial aún no está definida. Se publicará aquí antes del lanzamiento." },
      { h: "Problemas en una propuesta", p: "Puedes cancelar una propuesta en curso desde su página de seguimiento. Si sospechas fraude, usa el botón “Denunciar”." },
    ],
  },
};
