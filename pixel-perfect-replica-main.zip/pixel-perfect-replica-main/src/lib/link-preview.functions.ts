import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Reads public Open Graph / schema.org metadata from a link.
 * Only returns fields actually present on the page — never guesses.
 * Respects blocks: if the site refuses or the content isn't HTML, returns nothing.
 */
export const fetchLinkPreview = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ url: z.string().url().max(2000) }).parse(d))
  .handler(async ({ data }) => {
    const empty = { title: null as string | null, image: null as string | null, price: null as number | null, currency: null as string | null, store: null as string | null };
    let u: URL;
    try {
      u = new URL(data.url);
    } catch {
      return empty;
    }
    if (!["http:", "https:"].includes(u.protocol)) return empty;
    const host = u.hostname;
    if (host === "localhost" || /^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|0\.)/.test(host) || host.endsWith(".local") || host.includes(":")) return empty;
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 6000);
      const res = await fetch(u.toString(), {
        signal: ctrl.signal,
        headers: { "user-agent": "WishmadeLinkPreview/1.0 (+https://wishmade)", accept: "text/html" },
        redirect: "follow",
      });
      clearTimeout(timer);
      if (!res.ok || !(res.headers.get("content-type") ?? "").includes("text/html")) return empty;
      const html = (await res.text()).slice(0, 400_000);
      const meta = (prop: string) => {
        const re = new RegExp(`<meta[^>]+(?:property|name|itemprop)=["']${prop}["'][^>]*content=["']([^"']+)["']|<meta[^>]+content=["']([^"']+)["'][^>]*(?:property|name|itemprop)=["']${prop}["']`, "i");
        const m = html.match(re);
        return m ? (m[1] ?? m[2] ?? "").trim() : null;
      };
      const decode = (s: string | null) => s?.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'") ?? null;
      const title = decode(meta("og:title") ?? meta("twitter:title"));
      let image = decode(meta("og:image") ?? meta("twitter:image"));
      if (image) {
        try {
          image = new URL(image, u).toString();
          if (!image.startsWith("https://")) image = null;
        } catch {
          image = null;
        }
      }
      const priceRaw = meta("product:price:amount") ?? meta("og:price:amount") ?? meta("price");
      const price = priceRaw && /^\d+([.,]\d{1,2})?$/.test(priceRaw) ? Number(priceRaw.replace(",", ".")) : null;
      const currency = meta("product:price:currency") ?? meta("og:price:currency") ?? meta("priceCurrency");
      const store = decode(meta("og:site_name"));
      return { title: title?.slice(0, 120) ?? null, image, price, currency: currency && /^[A-Z]{3}$/.test(currency) ? currency : null, store: store?.slice(0, 80) ?? null };
    } catch {
      return empty;
    }
  });
