import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import type { Lang } from "./i18n";

export type Wish = Database["public"]["Tables"]["wishes"]["Row"];
export type WishStatus = Database["public"]["Enums"]["wish_status"];
export type FulfillmentStatus = Database["public"]["Enums"]["fulfillment_status"];

export const CATEGORIES: Record<string, Record<Lang, string>> = {
  tech: { pt: "Tecnologia e eletrónica", en: "Tech & electronics", es: "Tecnología y electrónica" },
  fashion: { pt: "Roupa e acessórios", en: "Clothing & accessories", es: "Ropa y accesorios" },
  books: { pt: "Livros e estudo", en: "Books & study", es: "Libros y estudio" },
  stays: { pt: "Hotéis e alojamento", en: "Hotels & stays", es: "Hoteles y alojamiento" },
  travel: { pt: "Viagens", en: "Travel", es: "Viajes" },
  experiences: { pt: "Atividades e experiências", en: "Activities & experiences", es: "Actividades y experiencias" },
  home: { pt: "Casa", en: "Home", es: "Hogar" },
  help: { pt: "Ajuda e serviços", en: "Help & services", es: "Ayuda y servicios" },
  other: { pt: "Outros", en: "Other", es: "Otros" },
};

export const COUNTRIES = [
  "PT", "ES", "FR", "DE", "IT", "NL", "BE", "LU", "IE", "AT", "CH", "PL", "CZ", "SK", "HU", "RO", "BG",
  "GR", "HR", "SI", "DK", "SE", "FI", "NO", "EE", "LV", "LT", "CY", "MT", "GB", "IS",
];
export const CURRENCIES = ["EUR", "GBP", "CHF", "PLN", "CZK", "SEK", "DKK", "NOK", "HUF", "RON", "BGN"];

export function countryName(code: string, lang: Lang) {
  try {
    return new Intl.DisplayNames([lang], { type: "region" }).of(code) ?? code;
  } catch {
    return code;
  }
}

export function formatPrice(v: number, currency: string, lang: Lang) {
  return new Intl.NumberFormat(lang === "pt" ? "pt-PT" : lang, { style: "currency", currency }).format(v);
}

export function formatDate(d: string, lang: Lang) {
  return new Intl.DateTimeFormat(lang === "pt" ? "pt-PT" : lang, { dateStyle: "medium" }).format(new Date(d));
}

/** Images live in a private bucket; resolve paths to signed URLs. External http(s) URLs pass through. */
export function useImageUrl(path: string | null | undefined) {
  return useQuery({
    queryKey: ["img", path],
    enabled: !!path,
    staleTime: 1000 * 60 * 60 * 6,
    queryFn: async () => {
      if (!path) return null;
      if (/^https?:\/\//.test(path)) return path;
      const { data } = await supabase.storage.from("wish-images").createSignedUrl(path, 60 * 60 * 24);
      return data?.signedUrl ?? null;
    },
  }).data;
}

export async function uploadImage(userId: string, file: File) {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type)) throw new Error("type");
  if (file.size > 5 * 1024 * 1024) throw new Error("size");
  const ext = file.type.split("/")[1];
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from("wish-images").upload(path, file, { contentType: file.type });
  if (error) throw error;
  return path;
}

export const WISH_SELECT = "*, profiles:user_id(id, display_name, avatar_url)";
export type WishWithAuthor = Wish & { profiles: { id: string; display_name: string; avatar_url: string | null } | null };
