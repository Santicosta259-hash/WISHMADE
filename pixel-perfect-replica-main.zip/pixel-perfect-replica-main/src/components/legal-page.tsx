import { useI18n, type TKey } from "@/lib/i18n";
import { LEGAL, type LegalKey } from "@/lib/content";
import { PageShell } from "@/components/site";

export function LegalPage({ k, titleKey, draft = true }: { k: LegalKey; titleKey: TKey; draft?: boolean }) {
  const { t, lang } = useI18n();
  return (
    <PageShell>
      <article className="mx-auto max-w-2xl space-y-8">
        <h1 className="text-4xl font-bold">{t(titleKey)}</h1>
        {draft && <p className="rounded-md border bg-accent p-3 text-sm">{t("legal_draft")}</p>}
        {LEGAL[k][lang].map((s) => (
          <section key={s.h} className="space-y-2">
            <h2 className="text-xl font-semibold">{s.h}</h2>
            <p className="leading-relaxed text-muted-foreground">{s.p}</p>
          </section>
        ))}
      </article>
    </PageShell>
  );
}
