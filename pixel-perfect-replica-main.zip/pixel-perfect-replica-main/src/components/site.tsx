import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, Heart, ImageOff, Menu, Plus, User as UserIcon } from "lucide-react";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { LANGS, useI18n, type TKey } from "@/lib/i18n";
import { CATEGORIES, formatPrice, useImageUrl, type WishStatus, type WishWithAuthor } from "@/lib/wishes";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold tracking-tight">
      <span className="grid h-7 w-7 place-items-center rounded-md bg-primary text-primary-foreground text-sm">W</span>
      wishmade
      <span className="h-1.5 w-1.5 rounded-full bg-signal" />
    </Link>
  );
}

function LangSwitch() {
  const { lang, setLang } = useI18n();
  return (
    <div className="flex rounded-md border p-0.5 font-mono text-xs">
      {LANGS.map((l) => (
        <button
          key={l}
          onClick={() => setLang(l)}
          className={`rounded px-2 py-1 uppercase transition ${lang === l ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
        >
          {l}
        </button>
      ))}
    </div>
  );
}

export function SiteHeader() {
  const { t } = useI18n();
  const { user } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const unread = useQuery({
    queryKey: ["unread", user?.id],
    enabled: !!user,
    refetchInterval: 60_000,
    queryFn: async () => {
      const { count } = await supabase.from("notifications").select("id", { count: "exact", head: true }).eq("read", false);
      return count ?? 0;
    },
  }).data;

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur">
      <div className="container-page flex h-16 items-center justify-between gap-4">
        <div className="flex items-center gap-8">
          <Logo />
          <nav className="hidden items-center gap-6 text-sm md:flex">
            <Link to="/explore" className="text-muted-foreground hover:text-foreground" activeProps={{ className: "text-foreground font-medium" }}>
              {t("nav_explore")}
            </Link>
            <Link to="/help" className="text-muted-foreground hover:text-foreground" activeProps={{ className: "text-foreground font-medium" }}>
              {t("nav_help")}
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden sm:block"><LangSwitch /></div>
          <Button asChild size="sm" className="hidden sm:inline-flex">
            <Link to="/new"><Plus className="h-4 w-4" />{t("nav_publish")}</Link>
          </Button>
          {user ? (
            <>
              <Button asChild variant="ghost" size="icon" className="relative" aria-label={t("nav_notifications")}>
                <Link to="/notifications">
                  <Bell className="h-5 w-5" />
                  {!!unread && <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-signal" />}
                </Link>
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon" aria-label={t("nav_me")}><UserIcon className="h-4 w-4" /></Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild><Link to="/me">{t("nav_me")}</Link></DropdownMenuItem>
                  <DropdownMenuItem asChild><Link to="/u/$id" params={{ id: user.id }}>Perfil público</Link></DropdownMenuItem>
                  <DropdownMenuItem asChild><Link to="/settings">{t("nav_settings")}</Link></DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={signOut}>{t("nav_signout")}</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <Button asChild variant="outline" size="sm"><Link to="/auth">{t("nav_signin")}</Link></Button>
          )}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden" aria-label="Menu"><Menu className="h-5 w-5" /></Button>
            </SheetTrigger>
            <SheetContent className="flex flex-col gap-4 pt-12">
              <Link to="/explore" className="text-lg">{t("nav_explore")}</Link>
              <Link to="/new" className="text-lg">{t("nav_publish")}</Link>
              <Link to="/help" className="text-lg">{t("nav_help")}</Link>
              <LangSwitch />
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  const { t } = useI18n();
  const links = [
    ["/faq", "faq_title"], ["/help", "help_title"], ["/rules", "rules_title"],
    ["/terms", "terms_title"], ["/privacy", "privacy_title"], ["/cookies", "cookies_title"],
  ] as const satisfies readonly (readonly [string, TKey])[];
  return (
    <footer className="mt-24 border-t">
      <div className="container-page grid gap-8 py-12 md:grid-cols-[1fr_2fr]">
        <div className="space-y-3">
          <Logo />
          <p className="text-sm text-muted-foreground">{t("footer_tag")}</p>
        </div>
        <ul className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
          {links.map(([to, k]) => (
            <li key={to}><Link to={to} className="text-muted-foreground hover:text-foreground">{t(k)}</Link></li>
          ))}
        </ul>
      </div>
      <div className="container-page border-t py-5 font-mono text-xs text-muted-foreground">© {new Date().getFullYear()} Wishmade</div>
    </footer>
  );
}

export function StatusBadge({ status }: { status: WishStatus }) {
  const { t } = useI18n();
  const tone: Record<WishStatus, string> = {
    draft: "bg-muted text-muted-foreground",
    published: "bg-secondary text-secondary-foreground",
    in_progress: "bg-accent text-accent-foreground",
    confirmed: "bg-signal text-signal-foreground",
    completed: "bg-primary text-primary-foreground",
    cancelled: "bg-muted text-muted-foreground line-through",
  };
  return <Badge className={`rounded-sm border-0 font-mono text-[10px] uppercase tracking-wider ${tone[status]}`}>{t(`st_${status}` as TKey)}</Badge>;
}

export function WishImage({ path, alt, className = "" }: { path: string | null; alt: string; className?: string }) {
  const url = useImageUrl(path);
  const { t } = useI18n();
  if (path && url) return <img src={url} alt={alt} loading="lazy" className={`h-full w-full object-cover ${className}`} />;
  return (
    <div className={`flex h-full w-full flex-col items-center justify-center gap-2 bg-muted text-muted-foreground ${className}`}>
      <ImageOff className="h-6 w-6" />
      <span className="font-mono text-[10px] uppercase tracking-widest">{t("no_image")}</span>
    </div>
  );
}

export function WishCard({ wish }: { wish: WishWithAuthor }) {
  const { t, lang } = useI18n();
  return (
    <Link to="/w/$id" params={{ id: wish.id }} className="group flex flex-col overflow-hidden rounded-lg border bg-card transition hover:-translate-y-0.5 hover:shadow-card">
      <div className="relative aspect-[4/3] overflow-hidden">
        <WishImage path={wish.image_url} alt={wish.title} className="transition duration-500 group-hover:scale-[1.03]" />
        <div className="absolute left-3 top-3"><StatusBadge status={wish.status} /></div>
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <span className="eyebrow">{CATEGORIES[wish.category]?.[lang] ?? wish.category}</span>
        <h3 className="line-clamp-2 font-display text-base font-semibold leading-snug">{wish.title}</h3>
        <div className="mt-auto flex items-center justify-between pt-2 text-sm text-muted-foreground">
          <span className="truncate">{t("by")} {wish.profiles?.display_name || "—"}</span>
          <span className="flex items-center gap-1"><Heart className="h-3.5 w-3.5" />{wish.likes_count}</span>
        </div>
        {wish.reference_price != null && (
          <div className="text-sm"><span className="text-muted-foreground">{t("ref_price")}: </span>{formatPrice(Number(wish.reference_price), wish.currency, lang)}</div>
        )}
      </div>
    </Link>
  );
}

export function EmptyState({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="rounded-lg border border-dashed px-6 py-16 text-center">
      <p className="mx-auto max-w-md text-muted-foreground">{children}</p>
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}

export function ReportDialog({ wishId, userId }: { wishId?: string; userId?: string }) {
  const { t } = useI18n();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("spam");
  const [details, setDetails] = useState("");
  const [busy, setBusy] = useState(false);
  const reasons = ["spam", "fraud", "inappropriate", "prohibited", "other"];

  async function submit() {
    if (!user) return;
    setBusy(true);
    const { error } = await supabase.from("reports").insert({
      reporter_id: user.id, wish_id: wishId ?? null, reported_user_id: userId ?? null, reason, details: details.trim() || null,
    });
    setBusy(false);
    if (error) return toast.error(t("error_generic"));
    toast.success(t("report_sent"));
    setOpen(false);
    setDetails("");
  }

  return (
    <Dialog open={open} onOpenChange={(o) => (user ? setOpen(o) : navigate({ to: "/auth" }))}>
      <DialogTrigger asChild>
        <button className="text-xs text-muted-foreground underline-offset-4 hover:underline">{t("report")}</button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>{t("report_title")}</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>{t("report_reason")}</Label>
            <div className="grid gap-2">
              {reasons.map((r) => (
                <label key={r} className="flex items-center gap-2 text-sm">
                  <input type="radio" name="reason" checked={reason === r} onChange={() => setReason(r)} />
                  {t(`reason_${r}` as TKey)}
                </label>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <Label>{t("report_details")}</Label>
            <Textarea maxLength={1000} value={details} onChange={(e) => setDetails(e.target.value)} />
          </div>
          <Button onClick={submit} disabled={busy} className="w-full">{t("report_send")}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function PageShell({ children }: { children: ReactNode }) {
  return <main className="container-page py-10 md:py-14">{children}</main>;
}
