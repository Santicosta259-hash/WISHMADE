import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/legal-page";

export const Route = createFileRoute("/cookies")({
  head: () => ({
    meta: [
      { title: "Política de cookies — Wishmade" },
      { name: "description", content: "Política de cookies da Wishmade." },
      { property: "og:title", content: "Política de cookies — Wishmade" },
      { property: "og:description", content: "Política de cookies da Wishmade." },
    ],
  }),
  component: () => <LegalPage k="cookies" titleKey="cookies_title" />,
});
