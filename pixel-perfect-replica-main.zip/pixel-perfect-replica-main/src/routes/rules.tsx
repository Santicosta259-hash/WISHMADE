import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/legal-page";

export const Route = createFileRoute("/rules")({
  head: () => ({
    meta: [
      { title: "Regras de utilização — Wishmade" },
      { name: "description", content: "Regras de utilização da Wishmade." },
      { property: "og:title", content: "Regras de utilização — Wishmade" },
      { property: "og:description", content: "Regras de utilização da Wishmade." },
    ],
  }),
  component: () => <LegalPage k="rules" titleKey="rules_title" />,
});
