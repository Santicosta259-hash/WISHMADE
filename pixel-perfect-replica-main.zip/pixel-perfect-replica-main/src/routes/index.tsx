import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Eye, Lock, ShieldCheck, Ban } from "lucide-react";
import heroImg from "@/assets/hero.jpg";
import { supabase } from "@/integrations/supabase/client";
import { useI18n, type TKey } from "@/lib/i18n";
import { FAQ } from "@/lib/content";
import { WISH_SELECT, type WishWithAuthor } from "@/lib/wishes";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { WishCard } from "@/components/site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Wishmade — Partilha um desejo. Alguém pode torná-lo real." },
      { name: "description", content: "A Wishmade liga quem tem um desejo a quem o quer realizar: produtos, viagens, experiências ou ajuda." },
      { property: "og:title", content: "Wishmade — Desejos reais, feitos realidade" },
      { property: "og:description", content: "Partilha um desejo ou realiza o de outra pessoa." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const { t, lang } = useI18n();
  const recent = useQuery({
    queryKey: ["wishes", "recent"],
    queryFn: async () => {
      const { data, error } = await supabase.from("wishes").select(WISH_SELECT).neq("status", "draft").order("created_at", { ascending: false }).limit(8);
      if (error) throw error;
      return data as unknown as WishWithAuthor[];
    },
  });

  const steps: [TKey, TKey][] = [["how_1_t", "how_1_d"], ["how_2_t", "how_2_d"], ["how_3_t", "how_3_d"], ["how_4_t", "how_4_d"]];
  const trust: [typeof Lock, TKey, TKey][] = [
    [Lock, "trust_1_t", "trust_1_d"], [ShieldCheck, "trust_2_t", "trust_2_d"], [Eye, "trust_3_t", "trust_3_d"], [Ban, "trust_4_t", "trust_4_d"],
  ];

  return (
    <main>
      <section className="surface-ink relative overflow-hidden">
        <div className="grid-lines absolute inset-0 opacity-60" />
        <div className="container-page relative grid items-center gap-10 py-16 md:grid-cols-[1.1fr_1fr] md:py-24">
          <div className="space-y-7">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-signal">{t("hero_eyebrow")}</p>
            <h1 className="text-4xl font-bold leading-[1.05] sm:text-5xl lg:text-6xl">{t("hero_title")}</h1>
            <p className="max-w-xl text-lg opacity-75">{t("hero_sub")}</p>
            <div className="flex flex-wrap gap-3">
              <Button asChild size="lg" variant="secondary"><Link to="/explore">{t("cta_explore")}<ArrowRight className="h-4 w-4" /></Link></Button>
              <Button asChild size="lg" variant="outline" className="border-primary-foreground/30 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground">
                <Link to="/new">{t("cta_publish")}</Link>
              </Button>
            </div>
          </div>
          <div className="relative mx-auto aspect-square w-full max-w-md overflow-hidden rounded-xl border border-primary-foreground/10">
            <img src={heroImg} alt="" width={1280} height={1280} className="h-full w-full object-cover" />
          </div>
        </div>
      </section>

      <section className="container-page grid gap-10 py-20 md:grid-cols-[1fr_2fr]">
        <h2 className="text-3xl font-bold">{t("mission_title")}</h2>
        <p className="text-xl leading-relaxed text-muted-foreground">{t("mission_text")}</p>
      </section>

      <section className="border-y bg-secondary/50">
        <div className="container-page py-20">
          <h2 className="mb-10 text-3xl font-bold">{t("how_title")}</h2>
          <ol className="grid gap-px overflow-hidden rounded-lg border bg-border sm:grid-cols-2 lg:grid-cols-4">
            {steps.map(([title, desc], i) => (
              <li key={title} className="space-y-3 bg-card p-6">
                <span className="font-mono text-sm text-signal">0{i + 1}</span>
                <h3 className="text-lg font-semibold">{t(title)}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{t(desc)}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {!!recent.data?.length && (
        <section className="container-page py-20">
          <div className="mb-8 flex items-end justify-between">
            <h2 className="text-3xl font-bold">{t("recent_title")}</h2>
            <Link to="/explore" className="text-sm font-medium underline-offset-4 hover:underline">{t("see_all")} →</Link>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {recent.data.map((w) => <WishCard key={w.id} wish={w} />)}
          </div>
        </section>
      )}

      <section className="container-page py-20">
        <h2 className="mb-10 text-3xl font-bold">{t("trust_title")}</h2>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {trust.map(([Icon, title, desc]) => (
            <div key={title} className="space-y-3 rounded-lg border p-6">
              <Icon className="h-5 w-5" />
              <h3 className="font-semibold">{t(title)}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{t(desc)}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container-page grid gap-10 py-12 md:grid-cols-[1fr_2fr]">
        <h2 className="text-3xl font-bold">{t("faq_title")}</h2>
        <Accordion type="single" collapsible>
          {FAQ[lang].map((f) => (
            <AccordionItem key={f.q} value={f.q}>
              <AccordionTrigger className="text-left">{f.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>
    </main>
  );
}
