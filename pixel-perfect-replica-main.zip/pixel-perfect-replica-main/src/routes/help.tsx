import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/legal-page";

export const Route = createFileRoute("/help")({
  head: () => ({
    meta: [
      { title: "Ajuda e contacto — Wishmade" },
      { name: "description", content: "Ajuda e contacto da Wishmade." },
      { property: "og:title", content: "Ajuda e contacto — Wishmade" },
      { property: "og:description", content: "Ajuda e contacto da Wishmade." },
    ],
  }),
  component: () => <LegalPage k="help" titleKey="help_title" draft={false} />,
});
