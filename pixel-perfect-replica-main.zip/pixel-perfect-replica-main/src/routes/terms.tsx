import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/legal-page";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Termos e condições — Wishmade" },
      { name: "description", content: "Termos e condições da Wishmade." },
      { property: "og:title", content: "Termos e condições — Wishmade" },
      { property: "og:description", content: "Termos e condições da Wishmade." },
    ],
  }),
  component: () => <LegalPage k="terms" titleKey="terms_title" />,
});
