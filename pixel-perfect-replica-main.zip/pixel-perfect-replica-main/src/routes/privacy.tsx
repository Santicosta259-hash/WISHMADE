import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/legal-page";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Política de privacidade — Wishmade" },
      { name: "description", content: "Política de privacidade da Wishmade." },
      { property: "og:title", content: "Política de privacidade — Wishmade" },
      { property: "og:description", content: "Política de privacidade da Wishmade." },
    ],
  }),
  component: () => <LegalPage k="privacy" titleKey="privacy_title" />,
});
