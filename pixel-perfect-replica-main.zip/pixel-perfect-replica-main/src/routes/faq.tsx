import { createFileRoute } from "@tanstack/react-router";
import { useI18n } from "@/lib/i18n";
import { FAQ } from "@/lib/content";
import { PageShell } from "@/components/site";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "Perguntas frequentes — Wishmade" },
      { name: "description", content: "Respostas sobre desejos, realizações, pagamentos e privacidade na Wishmade." },
      { property: "og:title", content: "Perguntas frequentes — Wishmade" },
      { property: "og:description", content: "Respostas sobre desejos, realizações, pagamentos e privacidade." },
    ],
  }),
  component: FaqPage,
});

function FaqPage() {
  const { t, lang } = useI18n();
  return (
    <PageShell>
      <div className="mx-auto max-w-2xl">
        <h1 className="mb-8 text-4xl font-bold">{t("faq_title")}</h1>
        <Accordion type="single" collapsible>
          {FAQ[lang].map((f) => (
            <AccordionItem key={f.q} value={f.q}>
              <AccordionTrigger className="text-left">{f.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </PageShell>
  );
}
