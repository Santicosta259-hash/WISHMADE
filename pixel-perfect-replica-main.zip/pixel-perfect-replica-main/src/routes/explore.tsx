import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/lib/i18n";
import { CATEGORIES, countryName, WISH_SELECT, type WishWithAuthor } from "@/lib/wishes";
import { EmptyState, PageShell, WishCard } from "@/components/site";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const searchSchema = z.object({
  q: z.string().optional(),
  cat: z.string().optional(),
  country: z.string().optional(),
  sort: z.enum(["recent", "popular"]).optional(),
});

export const Route = createFileRoute("/explore")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Explorar desejos — Wishmade" },
      { name: "description", content: "Descobre desejos reais publicados por pessoas na Wishmade e decide realizar um." },
      { property: "og:title", content: "Explorar desejos — Wishmade" },
      { property: "og:description", content: "Descobre desejos reais e decide realizar um." },
    ],
  }),
  component: Explore,
});

function Explore() {
  const { t, lang } = useI18n();
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const [q, setQ] = useState(search.q ?? "");
  useEffect(() => setQ(search.q ?? ""), [search.q]);
  const sort = search.sort ?? "recent";

  const countries = useQuery({
    queryKey: ["wish-countries"],
    queryFn: async () => {
      const { data } = await supabase.from("wishes").select("country").neq("status", "draft").limit(1000);
      return [...new Set((data ?? []).map((r) => r.country))];
    },
  }).data ?? [];

  const wishes = useQuery({
    queryKey: ["wishes", "explore", search],
    queryFn: async () => {
      let query = supabase.from("wishes").select(WISH_SELECT).neq("status", "draft");
      const term = search.q?.trim().replace(/[%,()]/g, " ");
      if (term) query = query.or(`title.ilike.%${term}%,description.ilike.%${term}%`);
      if (search.cat) query = query.eq("category", search.cat);
      if (search.country) query = query.eq("country", search.country);
      query = sort === "popular" ? query.order("likes_count", { ascending: false }).order("created_at", { ascending: false }) : query.order("created_at", { ascending: false });
      const { data, error } = await query.limit(60);
      if (error) throw error;
      return data as unknown as WishWithAuthor[];
    },
  });

  const filtered = !!(search.q || search.cat || search.country);

  return (
    <PageShell>
      <h1 className="mb-8 text-4xl font-bold">{t("explore_title")}</h1>
      <div className="mb-8 grid gap-3 md:grid-cols-[1fr_auto_auto_auto]">
        <form onSubmit={(e) => { e.preventDefault(); navigate({ search: (s) => ({ ...s, q: q || undefined }) }); }} className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search_placeholder")} className="pl-9" maxLength={100} />
        </form>
        <Select value={search.cat ?? "all"} onValueChange={(v) => navigate({ search: (s) => ({ ...s, cat: v === "all" ? undefined : v }) })}>
          <SelectTrigger className="md:w-56"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("all_categories")}</SelectItem>
            {Object.entries(CATEGORIES).map(([k, v]) => <SelectItem key={k} value={k}>{v[lang]}</SelectItem>)}
          </SelectContent>
        </Select>
        {countries.length > 1 && (
          <Select value={search.country ?? "all"} onValueChange={(v) => navigate({ search: (s) => ({ ...s, country: v === "all" ? undefined : v }) })}>
            <SelectTrigger className="md:w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t("all_countries")}</SelectItem>
              {countries.map((c) => <SelectItem key={c} value={c}>{countryName(c, lang)}</SelectItem>)}
            </SelectContent>
          </Select>
        )}
        <Select value={sort} onValueChange={(v) => navigate({ search: (s) => ({ ...s, sort: v as "recent" | "popular" }) })}>
          <SelectTrigger className="md:w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="recent">{t("sort_recent")}</SelectItem>
            <SelectItem value="popular">{t("sort_popular")}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {wishes.isLoading ? (
        <p className="text-muted-foreground">{t("loading")}</p>
      ) : wishes.isError ? (
        <p className="text-destructive">{t("error_generic")}</p>
      ) : !wishes.data?.length ? (
        <EmptyState action={!filtered && <Button asChild><Link to="/new">{t("cta_publish")}</Link></Button>}>
          {filtered ? t("no_results") : t("empty_wishes")}
        </EmptyState>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {wishes.data.map((w) => <WishCard key={w.id} wish={w} />)}
        </div>
      )}
    </PageShell>
  );
}
