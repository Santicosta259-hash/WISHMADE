import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import "@lovable.dev/cloud-auth-js/styles.css";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageShell } from "@/components/site";

export const Route = createFileRoute("/auth")({
  validateSearch: z.object({ redirect: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "Entrar ou criar conta — Wishmade" },
      { name: "description", content: "Inicia sessão ou cria a tua conta Wishmade para publicar e realizar desejos." },
      { property: "og:title", content: "Entrar — Wishmade" },
      { property: "og:description", content: "Inicia sessão ou cria a tua conta Wishmade." },
    ],
  }),
  component: AuthPage,
});

const safePath = (p?: string) => (p && p.startsWith("/") && !p.startsWith("//") ? p : "/me");

function AuthPage() {
  const { t } = useI18n();
  const { user } = useAuth();
  const { redirect } = Route.useSearch();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup" | "forgot">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (user) navigate({ to: safePath(redirect), replace: true });
  }, [user, redirect, navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setNotice(null);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else if (mode === "signup") {
        if (name.trim().length < 2) throw new Error(t("too_short"));
        const { error } = await supabase.auth.signUp({
          email, password,
          options: { emailRedirectTo: window.location.origin, data: { display_name: name.trim().slice(0, 60) } },
        });
        if (error) throw error;
        setNotice(t("auth_check_email"));
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
        if (error) throw error;
        setNotice(t("auth_reset_sent"));
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("error_generic"));
    } finally {
      setBusy(false);
    }
  }

  async function social(provider: "google" | "lovable") {
    if (redirect) sessionStorage.setItem("wm_after_auth", safePath(redirect));
    const r = await lovable.auth.signInWithOAuth(provider, { redirect_uri: window.location.origin });
    if (r.error) toast.error(t("error_generic"));
  }

  return (
    <PageShell>
      <div className="mx-auto max-w-sm space-y-6">
        <h1 className="text-3xl font-bold">
          {mode === "signin" ? t("auth_signin") : mode === "signup" ? t("auth_signup") : t("auth_forgot")}
        </h1>
        {notice && <p className="rounded-md border bg-accent p-3 text-sm">{notice}</p>}
        {mode !== "forgot" && (
          <>
            <div className="grid gap-2">
              <Button variant="outline" onClick={() => social("google")}>{t("auth_google")}</Button>
              <button type="button" className="lovable-auth-button" onClick={() => social("lovable")}>Continue with Lovable</button>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />{t("auth_or")}<span className="h-px flex-1 bg-border" /></div>
          </>
        )}
        <form onSubmit={submit} className="space-y-4">
          {mode === "signup" && (
            <div className="space-y-2"><Label htmlFor="name">{t("auth_name")}</Label><Input id="name" value={name} onChange={(e) => setName(e.target.value)} required maxLength={60} /></div>
          )}
          <div className="space-y-2"><Label htmlFor="email">{t("auth_email")}</Label><Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" /></div>
          {mode !== "forgot" && (
            <div className="space-y-2"><Label htmlFor="pw">{t("auth_password")}</Label><Input id="pw" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} autoComplete={mode === "signup" ? "new-password" : "current-password"} /></div>
          )}
          <Button type="submit" className="w-full" disabled={busy}>
            {mode === "signin" ? t("auth_signin") : mode === "signup" ? t("auth_signup") : t("auth_send_reset")}
          </Button>
          {mode === "signup" && <p className="text-xs text-muted-foreground">{t("auth_terms")} <Link to="/terms" className="underline">↗</Link></p>}
        </form>
        <div className="space-y-2 text-sm">
          {mode === "signin" && (
            <>
              <button className="block underline-offset-4 hover:underline" onClick={() => setMode("forgot")}>{t("auth_forgot")}</button>
              <p>{t("auth_no_account")} <button className="font-medium underline" onClick={() => setMode("signup")}>{t("auth_signup")}</button></p>
            </>
          )}
          {mode !== "signin" && (
            <p>{t("auth_have_account")} <button className="font-medium underline" onClick={() => setMode("signin")}>{t("auth_signin")}</button></p>
          )}
        </div>
      </div>
    </PageShell>
  );
}
