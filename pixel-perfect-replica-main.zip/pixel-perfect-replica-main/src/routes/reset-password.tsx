import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageShell } from "@/components/site";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Recuperar palavra-passe — Wishmade" },
      { name: "description", content: "Define uma nova palavra-passe para a tua conta Wishmade." },
      { property: "og:title", content: "Recuperar palavra-passe — Wishmade" },
      { property: "og:description", content: "Define uma nova palavra-passe." },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(t("auth_password_updated"));
    navigate({ to: "/me" });
  }
  return (
    <PageShell>
      <form onSubmit={submit} className="mx-auto max-w-sm space-y-4">
        <h1 className="text-3xl font-bold">{t("auth_new_password")}</h1>
        <div className="space-y-2"><Label htmlFor="pw">{t("auth_new_password")}</Label><Input id="pw" type="password" minLength={8} required value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="new-password" /></div>
        <Button type="submit" className="w-full" disabled={busy}>{t("auth_update_password")}</Button>
      </form>
    </PageShell>
  );
}
